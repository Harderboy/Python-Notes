# miniproject
just some small projects and notes

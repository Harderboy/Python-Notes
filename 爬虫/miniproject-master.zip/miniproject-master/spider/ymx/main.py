from scrapy import cmdline

cmdline.execute('scrapy crawl amazon'.split())









